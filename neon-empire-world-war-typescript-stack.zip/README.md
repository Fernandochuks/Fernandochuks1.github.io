# NEON EMPIRE: WORLD WAR — TypeScript Stack

A mobile-first Telegram Mini App starter for a multiplayer grand-strategy game. It uses React + TypeScript + Vite for the client, Node.js + TypeScript + Express for the API, WebSockets for live world events, and PostgreSQL schema for persistent records. Combat is server-authoritative; the browser cannot decide battle results.

## Requirements
- Node.js 20+
- PostgreSQL 14+ (recommended for durable production data)
- Telegram bot created with @BotFather for Telegram Web App authentication

## Run locally
1. Copy `.env.example` to `.env` and configure it.
2. Install packages: `npm install`
3. For the quick local prototype, set `ALLOW_DEMO_AUTH=true`.
4. Start API and frontend together: `npm run dev`
5. Open `http://localhost:5173`. API runs on port 3000.
6. For PostgreSQL, create a database and apply `server/db/schema.sql` with `npm run db:migrate` after setting `DATABASE_URL`.

## Telegram deployment
- Host the client and API on HTTPS.
- Set `TELEGRAM_BOT_TOKEN` to the bot token; set `ALLOW_DEMO_AUTH=false` in production.
- Set `CLIENT_ORIGIN` to the exact deployed client origin.
- Configure the Mini App URL with BotFather.
- If frontend and API are hosted on different origins, set `VITE_API_URL` to the API origin before building.
- Restrict CORS and use TLS at the reverse proxy/load balancer.

## Implemented in this starter
- Telegram `initData` HMAC validation and optional local demo auth.
- React Mini App UI with world map, empire resources, recruitment, military order queue, diplomacy, reports, and premium shop catalogue.
- Express API endpoints: `GET /health`, `GET /api/world`, `POST /api/recruit`, `POST /api/attack`, `POST /api/diplomacy`, `GET /api/leaderboard`, `GET /api/shop`.
- WebSocket event channel at `/ws`; server-side worker resolves queued attacks.
- PostgreSQL schema for players, empires, territories, wars, military orders, reports, diplomacy, and shop orders.

## Prototype limitations — read before launch
- The current world simulation and battle queue are in-memory, and only player/empire creation is written to PostgreSQL. This means world state, territory ownership, reports, diplomacy, and orders can be lost on restart. Complete the repository/transaction layer before production.
- PostgreSQL schema is supplied but not yet used for every game operation; apply migrations and finish durable repositories, locking, and idempotency before public multiplayer.
- The attack resolver is a basic prototype formula, not balanced production combat. Unclaimed territory colonization, diplomacy responses, alliances/war state, AI dialogue, and notification bot are not implemented yet.
- Shop displays premium items but intentionally disables checkout. TON Connect, Telegram Stars invoices, on-chain verification, and item fulfillment are NOT implemented in this stack version. Never grant purchased items based on a client-side success message; verify payments server-side and use durable idempotent order processing.
- The frontend WebSocket currently refreshes state when events arrive; production should add authenticated WebSocket sessions and per-empire event filtering.
- Use rate limiting, audit logs, structured logging, CSRF/origin protections as appropriate, secrets management, monitoring, and automated tests before launch.

## Game endpoints
All game endpoints except `/health` require valid Telegram Mini App initData or demo auth when enabled. Requests use JSON.

- `GET /api/world`
- `POST /api/recruit` — `{ "unit":"infantry", "quantity":50 }`
- `POST /api/attack` — `{ "targetId":"eastern-coast", "type":"land" }`
- `POST /api/diplomacy` — `{ "targetEmpireId":"...", "kind":"alliance", "body":"Propose a non-aggression pact." }`
- `GET /api/leaderboard`
- `GET /api/shop`

This repository is a runnable foundation, not a production-ready real-money game. Perform security review and load testing before launch.
