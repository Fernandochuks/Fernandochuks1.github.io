import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { Pool } from 'pg';
import { z } from 'zod';
import { createHmac, timingSafeEqual } from 'node:crypto';

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ noServer: true });
const port = Number(process.env.PORT || 3000);
const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined }) : null;
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') || true }));
app.use(express.json({ limit: '32kb' }));

// Shared-memory fallback is for local development only. Configure PostgreSQL for durable player records.
type Empire = { id:string; telegramId:string; username:string; name:string; color:string; credits:number; supplies:number; fuel:number; metal:number; prestige:number; forces:{infantry:number;armor:number;fighters:number;bombers:number;ships:number}; defense:{airDefense:number;fortifications:number;coastalDefense:number;radar:number} };
type Territory = { id:string; name:string; x:number; y:number; terrain:string; ownerId:string|null; defense:number };
const empires = new Map<string, Empire>();
const territories: Territory[] = [
  {id:'nova-prime',name:'Nova Prime',x:.23,y:.32,terrain:'Capital',ownerId:null,defense:12},
  {id:'eastern-coast',name:'Eastern Coast',x:.42,y:.57,terrain:'Coastal',ownerId:null,defense:9},
  {id:'iron-basin',name:'Iron Basin',x:.61,y:.3,terrain:'Industrial',ownerId:null,defense:11},
  {id:'frostline',name:'Frostline',x:.76,y:.56,terrain:'Tundra',ownerId:null,defense:8},
  {id:'solar-reach',name:'Solar Reach',x:.34,y:.78,terrain:'Desert',ownerId:null,defense:7},
  {id:'deepwater',name:'Deepwater',x:.83,y:.8,terrain:'Naval',ownerId:null,defense:10}
];
const reports: {id:string;empireId:string;title:string;body:string;at:string}[] = [];
const diplomacy: {id:string;from:string;to:string;kind:string;body:string;status:string;at:string}[] = [];
const orders: {id:string;empireId:string;target:string;type:string;status:string;resolvesAt:number}[] = [];
const uid=()=>crypto.randomUUID();
function publicEmpire(e:Empire){return {...e};}
function snapshot(e:Empire){return {empire:publicEmpire(e),territories:territories.map(t=>({...t,owner: t.ownerId ? empires.get(t.ownerId)?.name || 'Unknown' : null})),reports:reports.filter(r=>r.empireId===e.id).slice(-15).reverse(),diplomacy:diplomacy.filter(d=>d.from===e.id||d.to===e.id).slice(-15).reverse(),orders:orders.filter(o=>o.empireId===e.id).slice(-10).reverse(),players:empires.size};}
function broadcast(event:unknown){const data=JSON.stringify(event); for(const client of wss.clients) if(client.readyState===WebSocket.OPEN) client.send(data);}
function verifyTelegram(initData:string, botToken:string): Record<string,string> | null {
 try { const p=new URLSearchParams(initData); const hash=p.get('hash'); if(!hash)return null; p.delete('hash'); const check=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n'); const secret=createHmac('sha256','WebAppData').update(botToken).digest(); const expected=createHmac('sha256',secret).update(check).digest('hex'); const a=Buffer.from(expected,'hex'),b=Buffer.from(hash,'hex'); if(a.length!==b.length||!timingSafeEqual(a,b))return null; const auth=Number(p.get('auth_date')||0); if(!auth||Date.now()/1000-auth>86400)return null; return Object.fromEntries(p.entries()); } catch { return null; }
}
async function auth(req:express.Request,res:express.Response,next:express.NextFunction){
 const initData=String(req.header('x-telegram-init-data')||''); let user:{id:string;username:string};
 if(initData && process.env.TELEGRAM_BOT_TOKEN){const values=verifyTelegram(initData,process.env.TELEGRAM_BOT_TOKEN); if(!values){res.status(401).json({error:'Invalid Telegram session'});return;} try {const raw=JSON.parse(values.user||'{}'); if(!raw.id)throw Error(); user={id:String(raw.id),username:String(raw.username||raw.first_name||'Commander')};}catch{res.status(401).json({error:'Missing Telegram user'});return;}}
 else if(process.env.ALLOW_DEMO_AUTH==='true'){user={id:String(req.header('x-demo-user')||'10001'),username:String(req.header('x-demo-name')||'Commander')};}
 else {res.status(401).json({error:'Telegram authentication required'});return;}
 let e=[...empires.values()].find(x=>x.telegramId===user.id);
 if(!e){e={id:uid(),telegramId:user.id,username:user.username,name:`${user.username} Empire`,color:'#38bdf8',credits:1200,supplies:700,fuel:500,metal:700,prestige:0,forces:{infantry:160,armor:45,fighters:16,bombers:8,ships:12},defense:{airDefense:12,fortifications:10,coastalDefense:8,radar:5}}; empires.set(e.id,e); const free=territories.find(t=>!t.ownerId); if(free)free.ownerId=e.id; if(pool){pool.query('INSERT INTO players(telegram_user_id,username) VALUES($1,$2) ON CONFLICT(telegram_user_id) DO UPDATE SET username=EXCLUDED.username,last_seen_at=now()', [user.id,user.username]).then(async()=>{const p=await pool!.query('SELECT id FROM players WHERE telegram_user_id=$1',[user.id]);if(p.rows[0])await pool!.query('INSERT INTO empires(player_id,name,color) VALUES($1,$2,$3) ON CONFLICT(player_id) DO NOTHING',[p.rows[0].id,e!.name,e!.color]);}).catch(err=>console.error('PostgreSQL persistence error:',err.message));}}
 (req as any).empire=e; next();
}
app.get('/health',(_req,res)=>res.json({ok:true,service:'neon-empire-api',database:!!pool}));
app.get('/api/world',auth,(req,res)=>res.json(snapshot((req as any).empire)));
app.post('/api/recruit',auth,(req,res)=>{const schema=z.object({unit:z.enum(['infantry','armor','fighters','bombers','ships']),quantity:z.number().int().min(1).max(1000)});const parsed=schema.safeParse(req.body);if(!parsed.success){res.status(400).json({error:'Invalid recruitment order'});return;}const e:Empire=(req as any).empire;const {unit,quantity}=parsed.data;const costs={infantry:{credits:2,supplies:1},armor:{credits:12,metal:4},fighters:{credits:20,fuel:3},bombers:{credits:28,fuel:5},ships:{credits:35,metal:8}} as const;const c=costs[unit];const keys=Object.keys(c) as (keyof typeof c)[];for(const k of keys)if(e[k] < c[k]*quantity){res.status(400).json({error:`Not enough ${k}`});return;}for(const k of keys)(e as any)[k]-=c[k]*quantity;e.forces[unit]+=quantity;e.prestige+=Math.floor(quantity/10);reports.push({id:uid(),empireId:e.id,title:'Recruitment complete',body:`Recruited ${quantity} ${unit}.`,at:new Date().toISOString()});broadcast({type:'empire_updated',empireId:e.id,action:'recruit'});res.json(snapshot(e));});
app.post('/api/attack',auth,(req,res)=>{const schema=z.object({targetId:z.string().min(1),type:z.enum(['air','land','sea'])});const p=schema.safeParse(req.body);if(!p.success){res.status(400).json({error:'Choose a target and valid attack type'});return;}const e:Empire=(req as any).empire;const target=territories.find(t=>t.id===p.data.targetId);if(!target){res.status(404).json({error:'Territory not found'});return;}if(target.ownerId===e.id){res.status(400).json({error:'You cannot attack your own territory'});return;}if(!target.ownerId){res.status(400).json({error:'Unclaimed territories must be colonized in a future update'});return;}const cost=p.data.type==='air'?{fuel:40,credits:100}:p.data.type==='sea'?{fuel:60,credits:140}:{supplies:70,credits:120};for(const [k,v] of Object.entries(cost))if((e as any)[k]<v){res.status(400).json({error:`Not enough ${k}`});return;}for(const [k,v] of Object.entries(cost))(e as any)[k]-=v;const order={id:uid(),empireId:e.id,target:target.id,type:p.data.type,status:'queued',resolvesAt:Date.now()+(p.data.type==='air'?15:p.data.type==='sea'?60:35)*1000};orders.push(order);reports.push({id:uid(),empireId:e.id,title:'Attack order issued',body:`${p.data.type.toUpperCase()} strike against ${target.name} will resolve in approximately ${Math.round((order.resolvesAt-Date.now())/1000)} seconds.`,at:new Date().toISOString()});broadcast({type:'attack_queued',order});res.json({message:'Attack order queued',...snapshot(e)});});
app.post('/api/diplomacy',auth,(req,res)=>{const schema=z.object({targetEmpireId:z.string(),kind:z.enum(['message','alliance','ultimatum','peace']),body:z.string().trim().min(2).max(600)});const p=schema.safeParse(req.body);if(!p.success){res.status(400).json({error:'Invalid diplomatic message'});return;}const e:Empire=(req as any).empire;const target=empires.get(p.data.targetEmpireId);if(!target||target.id===e.id){res.status(404).json({error:'Choose another known empire'});return;}const d={id:uid(),from:e.id,to:target.id,kind:p.data.kind,body:p.data.body,status:'open',at:new Date().toISOString()};diplomacy.push(d);reports.push({id:uid(),empireId:e.id,title:'Diplomatic transmission sent',body:`${d.kind.toUpperCase()} to ${target.name}: ${d.body}`,at:new Date().toISOString()});broadcast({type:'diplomacy',message:d});res.json({ok:true,...snapshot(e)});});
app.get('/api/leaderboard',auth,(_req,res)=>res.json([...empires.values()].sort((a,b)=>b.prestige-a.prestige).map((e,i)=>({rank:i+1,name:e.name,prestige:e.prestige,territories:territories.filter(t=>t.ownerId===e.id).length}))));
const SHOP=[{id:'commander',name:'Premium Commander Pass',priceTon:'5',quality:'Elite',description:'30 days premium status'},{id:'citadel',name:'Citadel Fortress Pack',priceTon:'6',quality:'Fortress',description:'+25 air defense and fortification'},{id:'war-chest',name:'Imperial War Chest',priceTon:'7',quality:'Strategic',description:'12,000 supplies and 8,000 fuel'},{id:'army',name:'Elite Army Contract',priceTon:'8',quality:'Military',description:'Elite infantry, armor, fighters and bombers'},{id:'founder',name:'Founder Arsenal Bundle',priceTon:'10',quality:'Legendary',description:'Premium days, resources and reinforcements'},{id:'legacy',name:'Emperor’s Legacy Bundle',priceTon:'20',quality:'Mythic',description:'90 premium days and a major resource boost'}];
app.get('/api/shop',auth,(_req,res)=>res.json({items:SHOP,notice:'TON checkout is not wired in this scaffold. Never grant items based only on a client callback.'}));
// Simulation worker: orders resolve on the server, never on the client.
setInterval(()=>{const now=Date.now();for(const o of orders.filter(x=>x.status==='queued'&&x.resolvesAt<=now)){o.status='resolved';const e=empires.get(o.empireId);const t=territories.find(x=>x.id===o.target);if(e&&t){const power=o.type==='air'?e.forces.fighters+e.forces.bombers:e.forces.infantry+e.forces.armor+e.forces.ships;const score=power*Math.random();if(score>t.defense*12){const previous=t.ownerId;t.ownerId=e.id;t.defense=Math.max(3,t.defense-2);e.prestige+=25;reports.push({id:uid(),empireId:e.id,title:'Territory captured',body:`Your ${o.type} operation captured ${t.name}${previous?' from a rival empire':''}.`,at:new Date().toISOString()});}else{reports.push({id:uid(),empireId:e.id,title:'Attack repelled',body:`Your attack on ${t.name} was repelled by the defenders.`,at:new Date().toISOString()});}}broadcast({type:'order_resolved',orderId:o.id});}},1000);
server.on('upgrade', (request, socket, head) => { if(request.url!=='/ws'){socket.destroy();return;} wss.handleUpgrade(request,socket,head,ws=>wss.emit('connection',ws,request)); });
wss.on('connection',(ws)=>{ws.send(JSON.stringify({type:'connected',message:'Connected to NEON EMPIRE live world'}));});
server.listen(port,()=>console.log(`NEON EMPIRE API listening on :${port}`));
process.on('SIGTERM',async()=>{server.close();await pool?.end();process.exit(0);});
